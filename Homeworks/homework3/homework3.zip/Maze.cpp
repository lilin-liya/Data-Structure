/*
 * [TODO] delte this comment
 * Our test compiler is g++,
 * you can use '$ g++ -v' to see version, suggest 4.8 or newest,
 * add any header file you need from standard C++ library
 * and create any class or function you need to use
 */

/*
 * Use standard I/O to read test file and output answer.
 * There are three test file: testmap_1.txt, testmap_2.txt, testmap_3.txt,
 * and your output should like:
 * testmap_1: (1,1) (1,2) (1,3) (2,3) ...
 * More detail on course websit
 */
#include <iostream>
using namespace std;

int main()
{
	cout << 123 << endl;
	return 0;
}
